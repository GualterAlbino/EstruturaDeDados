#ifndef FILA_H_INCLUDED
#define FILA_H_INCLUDED

typedef int TipoDado; //Define o tipo de dado que ser� armazenado na Fila
const int MAXTAM = 8;  //define o n�mero m�ximo de elementos que a Fila pode armazenar

//Um construtor � um m�todo que deve ser executado obrigatoriamente antes da fila ser utilizada
void Fila_Construtor();

//Fun��o para indicar se a Fila est� ou n�o vazia (se exite ou n�o algum elemento armazenado)
bool Fila_Vazia();

//Fun��o para indicar se a Fila est� ou n�o cheia (se todas as posi��es do vetor foram ou n�o preenchidas)
bool Fila_Cheia();

//Fun��o para retornar a quantidade de elementos armazenados na Fila
int Fila_Tamanho();

//M�todo para adicionar elementos na Fila (Enfileirar)
//Se o elemento for Enfileirado (armazenado na Fila), o m�todo retorna verdadeiro
//caso contr�rio, retorna falso
//Esse m�todo tamb�m � conhecido como Enqueue
bool Fila_Enfileirar(TipoDado Elemento);

//M�todo para remover elementos da Fila
//Se o elemento for Desenfileirado (removido da Fila), o m�todo retorna verdadeiro
//caso contr�rio, retorna falso
//O Elemento na Frente da Fila � removido e retornado por refer�ncia pelo par�metro da fun��o
//Esse m�todo tamb�m � conhecido como Dequeue
bool Fila_Desenfileirar(TipoDado &Elemento);

//M�todo para retornar o elemento no topo da Fila sem reemov�-lo
//O elemento � retornado por refer�ncia pelo par�metro da fun��o
bool Fila_Frente(TipoDado &Elemento);

#endif // FILA_H_INCLUDED
