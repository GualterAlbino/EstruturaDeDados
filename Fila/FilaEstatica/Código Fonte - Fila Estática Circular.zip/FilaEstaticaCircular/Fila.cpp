//Bibliotecas necess�rias
#include <iostream>
#include "Fila.h"

//defini��o de vari�veis utilizadas para controlar e armazenar os dados na Fila
TipoDado Fila[MAXTAM];  //esta implementa��o utiliza mem�ria est�tica, ou seja, ser� utilizado
                        //um vetor para armazenar os dados na fila
                        //Nesse exemplo ser� criada uma fila de inteiros, mas poderia ser
                        //qualquer outro tipo de dado

int Frente, Tras;    //Vari�veis utilizadas para manter o controle do estado atual da Fila

int Contador;  //Vari�vel utilizada para armazenar a quantidade de elementos na Fila


//Um construtor � um m�todo que deve ser executado obrigatoriamente antes da fila ser utilizada
void Fila_Construtor()
{

   Frente = 0;          //Estado inicial da Fila
   Tras = -1;           //Com Frente indicando a posi��o 0 e Tras indicando a posi��o -1 do vetor Fila
                        //Isso indica que nenhum elemento foi enfileirado
                        //Frente e Tras [nos m�todos a seguir] sempre s�o utilizados no vetor Fila

   Contador = 0;   //Armazena a quantidade de elementos na Fila
                   //Como a Fila est� sendo constru�da, n�o h� elementos
}

//Fun��o para indicar se a Fila est� ou n�o vazia (se exite ou n�o algum elemento armazenado)
bool Fila_Vazia()
{

   return Contador == 0;  //Retorna verdadeiro se a quantidade de elementos for igual a 0 (Fila vazia)
                         //caso contr�rio, ser� retornado falso (operador de compara��o ==)
}

//Fun��o para indicar se a Fila est� ou n�o cheia (se todas as posi��es do vetor foram ou n�o preenchidas)
bool Fila_Cheia()
{
    if(Contador >= MAXTAM)  //Se a quantidade de elementos for maior ou igual a
                           //quantidade m�xima de elementos que podem ser armazenados na Fila
      return true;
    else
      return false;
}

//Fun��o para retornar a quantidade de elementos armazenados na Fila
int Fila_Tamanho()
{
    return Contador;   //� retornado o contador de elementos, manipulado nos m�todos de Enfileirar e Desenfileirar
                       //A express�o utilizada na Fila Est�tica Simples foi substitu�da por essa vari�vel, pois
                       //apesar de poder ser aplicada uma f�rmula sobre Fila Est�tica Circular para descobrir o n�mero
                       //de elementos, essa vari�vel Contador facilita a implementa��o das Fun��es Vazia, Cheia e Tamanho.

                       //O n�mero de elementos da Fila poderia ser descoberto tamb�m percorrendo-se as posi��es do vetor onde
                       //houvesse elementos v�lidos na Fila, mas devido ao custo, esse procedimento n�o foi utilizado, sendo
                       //substitu�do pela vari�vel Contador
}


//M�todo para adicionar elementos na Fila (Enfileirar)
//Se o elemento for Enfileirado (armazenado na Fila), o m�todo retorna verdadeiro
//caso contr�rio, retorna falso
//Esse m�todo tamb�m � conhecido como Enqueue
bool Fila_Enfileirar(TipoDado Elemento)
{

     if(!Fila_Cheia())  //Se a Fila n�o estiver cheia, podemos adicionar algum elemento
     {

        Tras = (Tras + 1) % MAXTAM; //Tras deve ser incrementado para indicar a posi��o onde o novo elemento deve ser inserido
                                    //O resto da divis�o (%) pelo tamanho do vetor � utilizado para que
                                    //um novo elemento possa ser inserido no in�cio do vetor.
                                    //Como j� foi verificada que a Fila n�o est� cheia (!Fila_Cheia()) ent�o
                                    //o indicador Tras n�o ser� igual ao indicador Frente, e portanto n�o
                                    //ir� ocasionar em perda de dados

        Fila[Tras] = Elemento; //O valor atual de Tras indica uma posi��o onde o elemento deve ser inserido


        Contador++;  //Contador � incrementado para indicar que um elemento foi inserido na Fila (enfileirado)

        return true;  //Retona verdadeiro, indicando que o elemento foi Enfileirado
     }
     else //caso a Fila esteja cheia
      return false;  //Retona falso, indicando que nenhum elemento foi Enfileirado (a Fila est� cheia)
}



//M�todo para remover elementos da Fila
//Se o elemento for Desenfileirado (removido da Fila), o m�todo retorna verdadeiro
//caso contr�rio, retorna falso
//O Elemento na Frente da Fila � removido e retornado por refer�ncia pelo par�metro da fun��o
//Esse m�todo tamb�m � conhecido como Dequeue
bool Fila_Desenfileirar(TipoDado &Elemento)
{

     if(!Fila_Vazia())  //Se a Fila n�o estiver vazia, podemos remover algum elemento
     {

        Elemento = Fila[Frente]; //O valor atual de Frente indica uma posi��o onde o elemento deve ser removido

        Frente = (Frente + 1) % MAXTAM;  //O incremento de Frente indica que o elemento n�o foi realmente removido.
                                         //Ele permanece no vetor, mas � considerado desenfileirado

                                         //Esse incremento indica tamb�m que se houver outro elemento na Fila,
                                         //este ser� indicado pelo novo valor de Frente
                                         //O resto da divis�o (%) pelo tamanho do vetor � utilizado para que Frente
                                         //possa voltar ao in�cio do vetor para indicar a posi��o desse outro elemento.

        Contador--;  //Contador � decrementado para indicar que um elemento foi "removido" na Fila (desenfileirado)

        return true;  //Retona verdadeiro, indicando que o elemento foi desenfileirado
     }
     else //caso a Fila esteja vazia
      return false;  //Retona falso, indicando que nenhum elemento foi desenfileirado (a Fila est� vazia)
}



//M�todo para retornar o elemento no topo da Fila sem reemov�-lo
//O elemento � retornado por refer�ncia pelo par�metro da fun��o
bool Fila_Frente(TipoDado &Elemento)
{
     if(!Fila_Vazia())  //primeiro deve-se conferir se a Fila n�o est� vazia
     {
        Elemento = Fila[Frente];  //assim como no m�todo Desenfileirar, o primeiro
                                  //elemento na Fila est� no �ndice do vetor indicado
                                  //pela vari�vel Frente
                                  //Repare que aqui a vari�vel Frente n�o � incrementada,
                                  //o que iria "remover" o elemento da Fila
        return true;  //retorna verdadeiro indicando que um elemento foi retornado
     }
     else //caso a Fila esteja vazia
          return false;  //retorna falso, indicando que n�o foi poss�vel retornar um elemento
}
